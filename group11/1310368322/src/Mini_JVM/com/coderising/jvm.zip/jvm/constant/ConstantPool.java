package com.coderising.jvm.constant;

import java.util.ArrayList;
import java.util.List;

public class ConstantPool {
	// �������е� ������������Ϣ
	private List<ConstantInfo> constantInfos = new ArrayList<ConstantInfo>();
	
	public ConstantPool(){
		
	}
	
	public void addConstantInfo(ConstantInfo info){
		this.constantInfos.add(info);
	}
	
	public ConstantInfo getConstantInfo(int index){
		return this.constantInfos.get(index);
	}
	
	public String getUTF8String(int index){
		return ((UTF8Info)this.constantInfos.get(index)).getValue();
	}
	
	public Object getSize(){
		return constantInfos.size() - 1;
	}
	
}
