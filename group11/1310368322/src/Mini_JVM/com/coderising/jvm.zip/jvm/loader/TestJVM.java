package com.coderising.jvm.loader;

public class TestJVM {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}
